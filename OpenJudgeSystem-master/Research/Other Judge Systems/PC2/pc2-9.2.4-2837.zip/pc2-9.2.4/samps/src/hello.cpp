
//
// File:    hello.cpp
// Purpose: prints hello world
// Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
//
// $Id: hello.cpp 1962 2009-11-25 03:42:12Z boudreat $
//

#include <iostream>
using namespace std;

main()
{
	cout << "Hello World.\n";
}

// eof 
