
//
// File:    NoOutput.java
// Purpose: exits with no output
// Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
// Oct 13 1998
//
// $Id: NoOutput.java 1962 2009-11-25 03:42:12Z boudreat $
//

public class NoOutput {
    public static void main(String[] args) 
    {
    }
}

// eof
